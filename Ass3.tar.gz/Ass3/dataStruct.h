#include <string>

using namespace std;

struct data{
        int counter = 1;
        string word;
};
